/* =====================================================
   CATALOGUE — mangas et chapitres du site
   Rassemble :
   - mangas.js            (contenu de départ, pages de test)
   - la base de données   (chapitres publiés par l'équipe)
   et remplit window.MANGAS, que le reste du site lit.

   Deux sources, selon config.js :
   - cloud : Supabase (base + stockage des images)
   - local : démo, tout reste sur l'appareil (IndexedDB)

   Catalog.ready          -> promesse : catalogue chargé
   Catalog.load(options)  -> recharge ({ brouillons: true } pour l'aperçu équipe)
   Catalog.renderCards(el)-> ajoute les cartes des mangas créés par l'équipe
   Catalog.admin          -> fonctions réservées à l'atelier
===================================================== */
(function () {
    "use strict";

    const STATIC = JSON.parse(JSON.stringify(window.MANGAS || []));
    const STATIC_IDS = new Set(STATIC.map(m => m.id));
    window.MANGAS = window.MANGAS || [];

    const ck = r => { if (r.error) throw r.error; return r.data; };
    const rand = () => Math.random().toString(36).slice(2, 8);

    /* ---------- IndexedDB (mode démo) ---------- */
    let dbPromise = null;
    function db() {
        if (!dbPromise) {
            dbPromise = new Promise((resolve, reject) => {
                const r = indexedDB.open("mbokal-atelier", 1);
                r.onupgradeneeded = () => {
                    const d = r.result;
                    d.createObjectStore("mangas", { keyPath: "id" });
                    d.createObjectStore("chapitres", { keyPath: "key" });
                    d.createObjectStore("blobs");
                };
                r.onsuccess = () => resolve(r.result);
                r.onerror = () => reject(r.error);
            });
        }
        return dbPromise;
    }
    function tx(store, mode, fn) {
        return db().then(d => new Promise((resolve, reject) => {
            const t = d.transaction(store, mode);
            const req = fn(t.objectStore(store));
            t.oncomplete = () => resolve(req && req.result);
            t.onerror = () => reject(t.error);
            t.onabort = () => reject(t.error);
        }));
    }
    const idb = {
        all: s => tx(s, "readonly", o => o.getAll()),
        get: (s, k) => tx(s, "readonly", o => o.get(k)),
        put: (s, v, k) => tx(s, "readwrite", o => (k === undefined ? o.put(v) : o.put(v, k))),
        del: (s, k) => tx(s, "readwrite", o => o.delete(k))
    };

    /* ---------- Source : démo (appareil) ---------- */
    const localDriver = {
        async isTeam() { return !!Mbokal.user(); },     // démo : tout compte connecté peut tester l'atelier
        async url(ref) {
            if (!ref) return null;
            if (ref.indexOf("idb:") === 0) {
                const blob = await idb.get("blobs", ref.slice(4));
                return blob ? URL.createObjectURL(blob) : null;
            }
            return ref;
        },
        rawMangas: () => idb.all("mangas"),
        async rawChapters(opts) {
            return (await idb.all("chapitres")).filter(c => opts.brouillons || c.statut === "publie");
        },
        saveManga: m => idb.put("mangas", { id: m.id, titre: m.titre, genres: m.genres, sens: m.sens, couverture: m.couverture || null }),
        async deleteManga(id) { await idb.del("mangas", id); },
        saveChapter: c => idb.put("chapitres", Object.assign({ key: c.manga_id + ":" + c.numero }, c)),
        async deleteChapter(mangaId, numero) { await idb.del("chapitres", mangaId + ":" + numero); },
        async upload(mangaId, blob) {
            const id = Date.now().toString(36) + "-" + rand();
            await idb.put("blobs", blob, id);
            return "idb:" + id;
        },
        async removeFiles(refs) { for (const r of refs) if (r && r.indexOf("idb:") === 0) await idb.del("blobs", r.slice(4)); }
    };

    /* ---------- Source : Supabase ---------- */
    const sbc = () => Mbokal._sb();
    const cloudDriver = {
        async isTeam() {
            const u = Mbokal.user();
            if (!u) return false;
            const r = await sbc().from("equipe").select("user_id").eq("user_id", u.id).maybeSingle();
            return !r.error && !!r.data;
        },
        url(ref) { return ref ? sbc().storage.from("pages").getPublicUrl(ref).data.publicUrl : null; },
        async rawMangas() { return ck(await sbc().from("mangas").select("*").order("created_at")); },
        async rawChapters(opts) {
            const run = cols => {
                let q = sbc().from("chapitres").select(cols);
                if (!opts.brouillons) q = q.eq("statut", "publie");
                return q;
            };
            let r = await run("manga_id,numero,titre,pages,statut,pages_langues");
            // Base pas encore mise à jour (colonne absente) : on lit sans les versions par langue
            if (r.error && /pages_langues/i.test(r.error.message || "")) r = await run("manga_id,numero,titre,pages,statut");
            return ck(r);
        },
        async saveManga(m) {
            ck(await sbc().from("mangas").upsert(
                { id: m.id, titre: m.titre, genres: m.genres, sens: m.sens, couverture: m.couverture || null },
                { onConflict: "id" }));
        },
        async deleteManga(id) { ck(await sbc().from("mangas").delete().eq("id", id)); },
        async saveChapter(c) {
            const row = { manga_id: c.manga_id, numero: c.numero, titre: c.titre, pages: c.pages, statut: c.statut,
                          pages_langues: c.pages_langues || {} };
            let r = await sbc().from("chapitres").upsert(row, { onConflict: "manga_id,numero" });
            // Colonne absente et aucune version par langue à enregistrer : on enregistre sans
            if (r.error && /pages_langues/i.test(r.error.message || "") && !Object.keys(row.pages_langues).length) {
                delete row.pages_langues;
                r = await sbc().from("chapitres").upsert(row, { onConflict: "manga_id,numero" });
            }
            ck(r);
        },
        async deleteChapter(mangaId, numero) {
            ck(await sbc().from("chapitres").delete().eq("manga_id", mangaId).eq("numero", numero));
        },
        async upload(mangaId, blob, ext) {
            const path = mangaId + "/" + Date.now().toString(36) + "-" + rand() + "." + ext;
            const r = await sbc().storage.from("pages").upload(path, blob, { contentType: blob.type, cacheControl: "31536000" });
            if (r.error) throw r.error;
            return path;
        },
        async removeFiles(refs) {
            const list = refs.filter(Boolean);
            if (list.length) await sbc().storage.from("pages").remove(list);
        }
    };

    function driver() {
        const m = Mbokal.mode;
        if (m === "cloud") return cloudDriver;
        if (m === "local") return localDriver;
        return null;                                  // service injoignable : catalogue de départ seulement
    }

    /* ---------- Assemblage ---------- */
    async function fetchRemote(drv, opts) {
        const [ms, cs] = await Promise.all([drv.rawMangas(), drv.rawChapters(opts)]);
        const mangas = await Promise.all(ms.map(async m => ({
            id: m.id, titre: m.titre, genres: m.genres, sens: m.sens, couverture: await drv.url(m.couverture)
        })));
        const chapitres = await Promise.all(cs.map(async c => {
            const pagesLangues = {};
            for (const code of Object.keys(c.pages_langues || {})) {
                pagesLangues[code] = await Promise.all((c.pages_langues[code] || []).map(p => drv.url(p)));
            }
            return {
                manga_id: c.manga_id, numero: c.numero, titre: c.titre, statut: c.statut,
                pages: await Promise.all((c.pages || []).map(p => drv.url(p))),
                pagesLangues
            };
        }));
        return { mangas, chapitres };
    }

    function merge(remote) {
        const out = STATIC.map(m => JSON.parse(JSON.stringify(m)));
        remote.mangas.forEach(m => {
            let t = out.find(x => x.id === m.id);
            if (!t) {
                t = { id: m.id, titre: m.titre, genres: m.genres || "", sens: m.sens || "rtl", chapitres: [] };
                out.push(t);
            } else {
                t.titre = m.titre || t.titre;
                if (m.genres) t.genres = m.genres;
                t.sens = m.sens || t.sens;
            }
            t.couverture = m.couverture || null;
            t.dynamique = !STATIC_IDS.has(m.id);
            const chs = remote.chapitres
                .filter(c => c.manga_id === m.id)
                .sort((a, b) => a.numero - b.numero)
                .map(c => ({ numero: c.numero, titre: c.titre, disponible: true, pages: c.pages, pagesLangues: c.pagesLangues || {}, brouillon: c.statut !== "publie" }));
            if (chs.length) t.chapitres = chs;       // sinon : on garde les pages de test de mangas.js
        });
        return out;
    }

    async function load(opts) {
        opts = opts || {};
        await Mbokal.ready;
        let remote = { mangas: [], chapitres: [] };
        const drv = driver();
        if (drv) { try { remote = await fetchRemote(drv, opts); } catch (e) { /* hors ligne : catalogue de départ */ } }
        const merged = merge(remote);
        window.MANGAS.length = 0;
        merged.forEach(m => window.MANGAS.push(m));
        return window.MANGAS;
    }

    /* ---------- Cartes des mangas créés par l'équipe ---------- */
    function el(tag, cls, text) {
        const n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined) n.textContent = text;
        return n;
    }

    function renderCards(container) {
        container.querySelectorAll("[data-dynamic]").forEach(n => n.remove());
        window.MANGAS.filter(m => m.dynamique && m.chapitres.some(c => !c.brouillon)).forEach(m => {
            const card = el("article", "manga-card");
            card.dataset.dynamic = "1";
            const cover = el("div", "cover default");
            if (m.couverture) {
                cover.style.backgroundImage = "url(\"" + m.couverture.replace(/"/g, "%22") + "\")";
                cover.style.backgroundSize = "cover";
                cover.style.backgroundPosition = "center";
            }
            const add = el("button", "add-button");
            add.type = "button";
            add.dataset.fav = m.id;
            add.setAttribute("aria-pressed", "false");
            add.setAttribute("aria-label", "Ajouter aux favoris");
            add.append(el("i", "fa-solid fa-plus"));
            cover.append(add, el("div", "cover-title", m.titre));

            const info = el("div", "card-info");
            const read = el("a", "read-button");
            read.href = "lecteur.html?manga=" + encodeURIComponent(m.id);
            read.append(el("i", "fa-solid fa-play"), " LIRE");
            info.append(el("h3", null, m.titre), el("p", null, m.genres), read);

            card.append(cover, info);
            container.append(card);
        });
        if (window.Mbokal && Mbokal.bindFavs) Mbokal.bindFavs();
    }

    /* ---------- Atelier (équipe) ---------- */
    const admin = {
        isTeam: async () => { await Mbokal.ready; const d = driver(); return d ? d.isTeam() : false; },
        async mangas() {
            const d = driver();
            const rows = await d.rawMangas();
            // Les mangas de départ (mangas.js) sont toujours modifiables, même absents de la base
            const have = new Set(rows.map(m => m.id));
            STATIC.forEach(s => { if (!have.has(s.id)) rows.push({ id: s.id, titre: s.titre, genres: s.genres, sens: s.sens, couverture: null }); });
            return Promise.all(rows.map(async m => ({
                id: m.id, titre: m.titre, genres: m.genres, sens: m.sens,
                couverture: m.couverture ? { ref: m.couverture, url: await d.url(m.couverture) } : null
            })));
        },
        async chapters(mangaId) {
            const d = driver();
            const rows = (await d.rawChapters({ brouillons: true })).filter(c => c.manga_id === mangaId);
            return Promise.all(rows.sort((a, b) => a.numero - b.numero).map(async c => {
                const pagesLangues = {};
                for (const code of Object.keys(c.pages_langues || {})) {
                    pagesLangues[code] = await Promise.all((c.pages_langues[code] || []).map(async p => ({ ref: p, url: await d.url(p) })));
                }
                return {
                    numero: c.numero, titre: c.titre, statut: c.statut, pagesLangues,
                    pages: await Promise.all((c.pages || []).map(async p => ({ ref: p, url: await d.url(p) })))
                };
            }));
        },
        saveManga: m => driver().saveManga(m),
        deleteManga: id => driver().deleteManga(id),
        async saveChapter(c) {
            const d = driver();
            // Un manga de départ est enregistré en base au premier chapitre créé
            const rows = await d.rawMangas();
            const s = STATIC.find(x => x.id === c.manga_id);
            if (s && !rows.some(m => m.id === s.id)) await d.saveManga({ id: s.id, titre: s.titre, genres: s.genres, sens: s.sens });
            return d.saveChapter(c);
        },
        deleteChapter: (id, n) => driver().deleteChapter(id, n),
        upload: (id, blob, ext) => driver().upload(id, blob, ext),
        removeFiles: refs => driver().removeFiles(refs),
        urlOf: ref => driver().url(ref)
    };

    const Catalog = { ready: null, load, renderCards, admin, staticIds: STATIC_IDS };
    window.Catalog = Catalog;

    // Chargement automatique, puis cartes dynamiques sur les pages qui les prévoient
    Catalog.ready = load().then(() => {
        const fill = () => document.querySelectorAll("[data-catalog]").forEach(renderCards);
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fill);
        else fill();
    });
})();
